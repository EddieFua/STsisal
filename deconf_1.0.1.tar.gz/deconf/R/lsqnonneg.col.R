`lsqnonneg.col` <-
function(C,d,
	x0=matrix(0,nrow=ncol(C),ncol=1),
	error.threshold=10 * eps() * .norm(C,1) * length(C))
{
  require(corpcor)

	return.list <- list()


	if (is.complex(C)==TRUE || is.complex(d)==TRUE) {
		#print("C and d must be real.")
		return (return.list)
	}


	# initialize variables
	verbosity = 1;

	m <- nrow(C)
	n <- ncol(C)


	P <- matrix(0,nrow=1,ncol=n)

	Z <- 1:n
	return.list[["x"]] <- x0
	if (length(return.list[["x"]][return.list[["x"]] < 0]) > 0)
   	   return.list[["x"]] <- t(P)


	ZZ <- Z
	return.list[["resid"]] <-  d - C %*% return.list[["x"]]
	w <- t(C) %*% return.list[["resid"]]

	# set up iteration criterion
	outeriter <- 0;
	iter <- 0;
	itmax <- 3 * n;
	return.list[["exitflag"]] <- 1;

	CP <- matrix(0,nrow=m,ncol=n)


	# outer loop to put variables into set to hold positive coefficients
#print(w[ZZ])
	while ( any(Z !=0) & any(w[ZZ] > error.threshold))

	{
   		outeriter <- outeriter + 1;
   		wt <- max(w[ZZ],na.rm=TRUE);
		q <- w[ZZ]
		index <- order(q,decreasing=TRUE)
		t2 <- ZZ[index[1]];


   		P[1,t2] <- t2;
   		Z[t2] <- 0;

   		PP <- (1:length(P))[P != 0];
   		ZZ <- (1:length(Z))[Z != 0];

   		nzz <- dim(ZZ);
		if(is.null(nzz) == TRUE) {
			nzz <- c(1,length(ZZ))
		}
   		CP[1:m,PP] <- C[,PP];
   		CP[,ZZ] <- matrix(0,nrow=m,ncol=nzz[2]);

		z <-pseudoinverse(CP) #pseudoinverse(CP)  #pinv(CP)
		z[is.na(z)] <- 0.001
		z<- z %*% d;

   		z[ZZ] <- matrix(0,ncol=nzz[2],nrow=nzz[1]);
   		# inner loop to remove elements from the positive set which no longer belong
  		while (any( z[PP] <= error.threshold))
		{
		      iter = iter + 1;
		      if (iter > itmax) {


		         if (verbosity==1) {
		          #  print("Exiting: Iteration count is exceeded, exiting LSQNONNEG.");
				#print("Try raising the tolerance error.threshold.")
         		   }
                     return.list[["exitflag"]] <- 0;
         		   return.list[["output.iterations"]] <- outeriter;
         		   return.list[["resnorm"]] <- sum(return.list[["resid"]] * return.list[["resid"]]);
         		   return.list[["x"]] <- z;
		         return.list[["lambda"]] <- w;
			   return.list[["output.algorithm"]] <- "active-set using svd"
			   return(return.list)
      		}

			index <- z <= error.threshold
      		QQ = (1:length(P))[index[,1] & P !=0];

			if (length(QQ) > 1)
	      		alpha <- min(return.list[["x"]][QQ] %/% (return.list[["x"]][QQ] - z[QQ]));
			if (length(QQ) ==1)
	      		alpha <- return.list[["x"]][QQ] /(return.list[["x"]][QQ] - z[QQ])



      		return.list[["x"]] <- return.list[["x"]] + alpha * (z - return.list[["x"]]);
			y <- (1:nrow(return.list[["x"]]))
      		ij1 <- y[abs(return.list[["x"]][,1]) < error.threshold]
			ij2 <- y[P != 0]
			ij <- intersect(ij1,ij2)
      		Z[ij]<- t(ij)

      		P[ij] <- matrix(0,nrow=1,ncol=length(ij));

      		PP <- (1:length(P))[P != 0];
      		ZZ <- (1:length(Z))[Z != 0];
			CP[1:m,PP] <- C[,PP];
      		nzz <- dim(ZZ);
      		if (is.null(nzz)==TRUE) {
				nzz <- c(1,length(ZZ))

			}
      		CP[,ZZ] <- matrix(0,nrow=m,ncol=nzz[2]);
			z[ZZ] <- matrix(0,nrow=nzz[2],ncol=nzz[1]);

      		z <-  pseudoinverse(CP)%*% d; #pinv(CP) %*% d;  #pseudoinverse(CP)%*% d

   		} #while
   		return.list[["x"]]<- z;
		return.list[["resid"]] <- d - C %*% return.list[["x"]];
   		w <-t(C) %*% return.list[["resid"]];

	}

	return.list[["lambda"]] <- w
	return.list[["resnorm"]] <- sum(return.list[["resid"]] * return.list[["resid"]])
	return.list[["output.iterations"]] <- outeriter
	return.list[["output.algorithm"]] <- "active-set using svd"


	if (verbosity > 1){
	   #print("Optimization terminated successfully.")
	}
	return(return.list)
}

