`apply.constraints.C` <-
function(C) {
	
	C2 <- normalize.col.in.matrix(C,col.value=1,method="sum")
	
	return (C2)
}

