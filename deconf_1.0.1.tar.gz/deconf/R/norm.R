`.norm` <-
function(m,type=2)
{
      value <- NA
	if (type==1){ #largest column sum
		v <- c()
		for (col in 1:ncol(m)) {
			v <- cbind(v,sum(abs(m[,col])))
		}
		value <- max(v)
	}
	if(type==2) {	# largest singular value of X, max(svd(X)$d).


   	     # options(show.error.messages = TRUE)

		try(value <- max(svd(m)$d)) #max(svd(m)$d)      # ge�ndert eigentlich     try(value <- max(fast.svd(m)$d)), aber fast.svd kann nicht gefunden werden

     		#print(.Last.value)
	     # options(show.error.messages = TRUE)
	}
	return(value)
}

