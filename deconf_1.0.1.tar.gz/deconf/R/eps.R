`eps` <-
function(){
	# Floating point relative accuracy. EPS is the distance from 1.0 to the next largest
	# floating point number. Value is taken from Matlab R12 running under Windows XP SP2,64 Bit
	return(2.2204e-016)
}

